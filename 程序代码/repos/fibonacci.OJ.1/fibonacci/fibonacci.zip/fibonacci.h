#ifndef __FIBONACCI_H
#define __FIBONACCI_H
#include<iostream>
using namespace std;
int fibonacci(int n);
#endif
